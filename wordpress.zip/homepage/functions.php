<?php
function  vumhp_messages($message = 0){
	$return = array(
						array("msg"=>"Something went wrong. Please review your data", "class"=>"error"),
						array("msg"=>"Setting updated.", "class"=>"updated"),
						array("msg"=>"Edit view updated.", "class"=>"updated"),
						array("msg"=>"Client view saved.", "class"=>"updated"),
						array("msg"=>"Title is required", "class"=>"error")
					);
	echo '<div id="message" class="'.$return[$message]["class"].' below-h2"><p>'.$return[$message]["msg"].'</p></div>';
}
function vumhp_get_menu_logo(){
	$menulogo = get_option("wpm_vumHP_Plugin_menu", true);
	if($menulogo ==""){
		$menulogo = WPDEV_PLUGIN_URL.'/images/homepage-logo-16.png';	
	}elseif($menulogo !="" && !isValidURL($menulogo)){
		$menulogo = get_bloginfo('stylesheet_directory').'/images/'. $menulogo;	
	}
	
	return $menulogo;
}
function vumhp_get_titlepage_logo(){
	$menulogo = get_option("wpm_vumHP_Plugin_title", true);
	
	if( $menulogo == "" ){
		$menulogo = WPDEV_PLUGIN_URL.'/images/homepage-logo-32.png';	
	}elseif( $menulogo !="" && !isValidURL( $menulogo )){
		$menulogo = get_bloginfo('stylesheet_directory').'/images/'. $menulogo;	
	}
	return $menulogo;
}
function vumhp_get_plugin_name_title() {
	$pluginTitleName = stripslashes(get_option("wpm_vumHP_Plugin_name_title", true));
	return $pluginTitleName;
}
function vumhp_can_edit_setting(){
	
	$current_user = wp_get_current_user();
	
	$users = get_option("wpm_vumHP_setting_visible", true);
	
	if( ($users == 0 && strtolower(vumhp_get_current_user_role()) == "administrator") || $current_user->ID == $users ) 
		return TRUE;
	else
		return FALSE;
}
function vumhp_can_edit_view() {

	$role = get_option("wpm_vumHP_canview_role", true);
	
if( $role >= vumhp_user_roles(vumhp_get_current_user_role() ) ) 
		return TRUE;
	else
		return FALSE;
}
function vumhp_current_userID() {
        global $wpdb;
	
	$current_user = wp_get_current_user();
	return $current_user->ID;
}
function vumhp_current_user($field = 'ID') {
        global $wpdb;
	
	$current_user = wp_get_current_user();
	return $current_user->$field;
}

function vumhp_get_current_user_role() {
	global $wp_roles;
	
	$current_user = wp_get_current_user();
	$roles = $current_user->roles;
	$role = array_shift($roles);
	
	return isset($wp_roles->role_names[$role]) ? translate_user_role($wp_roles->role_names[$role] ) : false;
}
function vumhp_user_roles($roleIndex = NULL) {
		global $wp_roles;
		$usersRole = $wp_roles->get_names();
		unset($usersRole["Subscriber"]);
		$count = 0;
		$return = array();
		foreach($usersRole as $name) {
			$count++;
			$return[$count] = $name;
		}
		
		if(!is_null($roleIndex))  {
			$trans = array_flip($return);
			return $trans[$roleIndex];
		}else{
			return $return;	
		}
}
function isValidURL($url)
{
	if(empty($url)) return false;
	return preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url);
}
function flash_data(){

}

function get_extention_img($file, $checkifIMG = FALSE) {
	
		$ext =  strtolower(pathinfo($file, PATHINFO_EXTENSION));
		$is_image = FALSE;
		
		if($ext == "png" || $ext == "jpg" || $ext == "gif" || $ext ==  "tiff"){
				$imgPath = $file;
				$is_image = FALSE;
		}elseif($ext =="zip" || $ext =="gz" || $ext =="tar" || $ext =="rar" || $ext =="7z" || $ext =="iso") {
			
				$imgPath = WPDEV_PLUGIN_URL . "/images/filetype_zip.png";
		}elseif($ext == "xlsx" || $ext == "xls") {
				$imgPath = WPDEV_PLUGIN_URL . "/images/xls_filetype.png";
		}elseif($ext == "doc" || $ext == "docx") {
				$imgPath = WPDEV_PLUGIN_URL . "/images/doc_filetype.png";
		}elseif($ext == "pdf") {
				$imgPath = WPDEV_PLUGIN_URL . "/images/filetype_pdf.png";
		}else{
			
				$imgPath = WPDEV_PLUGIN_URL . "/images/default.png";	
		} 
		if($checkifIMG == false) {
			return $imgPath;
		} else {
			return array( "imagelink" => $imgPath, "is_image" => $is_image );
		}
}
function vum_homepage($id, $element= array(), $imagesize = ""){
	global $vum_hp, $vum_homepage;
	$output = array();
	if(!isset($vum_homepage[$id])) return;
	if(is_array($vum_homepage[$id])) {
		if(count($element)){
			
			if(!isset($vum_homepage[$id][$element])) return false;
			
			if(!empty($imagesize)){
				if(!in_array($imagesize, array("thumbnail", "medium", "large","full"))) return;
				
					$attachID = $vum_homepage[$id]["attachedID"];
					$thumb_url = wp_get_attachment_image_src( $attachID, $imagesize, true );
					
					$path = $pathlink = $thumb_url[0];
					if($path =="") return;
					
					$checklink = get_extention_img($path, TRUE);
				// print_r($checklink);
					if(!$checklink['is_image']){
						$path = $checklink["imagelink"];	
					}
					
				if($element =="image"){
					echo '<img src="' . $path . '" class="' . $imagesize . ' ' . $imagesize . $attachID . '"/>';
				}elseif($element =="path"){
					echo $vum_homepage[$id]["path"];
				}
			} else {
				echo $vum_homepage[$id][$element];
			}
		}
	}else{
		echo $vum_homepage[$id];
	}
	return;
}
?>