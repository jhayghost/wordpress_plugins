jQuery(document).ready(function($) {
var formfield = "";
var siteurl = $("#siteurl").html() + "/images/";


/*	jQuery("#tabs").tabs(); 
	jQuery('#tabs').bind('tabsselect', function(event, ui) {
	jQuery('.return').val( ui.tab );});
*/
	jQuery('#wpm_vumHP_Plugin_menu_button').click(function() {
		formfield = jQuery('#wpm_vumHP_Plugin_menu').attr('name');
		tb_show('', 'media-upload.php?amp;TB_iframe=true');
		return false;
	});

	jQuery('#wpm_vumHP_Plugin_title_button').click(function() {
		formfield = jQuery('#wpm_vumHP_Plugin_title').attr('name');
		tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
		return false;
	});
	
	jQuery('.fileuploader').click(function() {
		formfield = jQuery(this).prev().attr('id');
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
	
	window.send_to_editor = function(html) {
		
		imgurl = jQuery('#hideElement').html(html).find("a").attr("href");
		var imgID = "";
		t(typeof jQuery('#hideElement').html(html).find("img").attr("class") );
		if(typeof jQuery('#hideElement').html(html).find("img").attr("class") !="undefined") {
			var imgClass = jQuery('#hideElement').html(html).find("img").attr("class").split("wp-image-");
				imgID = imgClass[1];
		}
		
		jQuery('#hideElement').html("");
		
//		imgurl = jQuery('img',html).attr('src');
		jQuery('#'+formfield).val(imgurl);
		tb_remove();
		
		if($('#'+formfield+"_img").length > 0){
			var ElementIndex = formfield.split("formData_");
			ext = imgurl.substr(imgurl.lastIndexOf('.') + 1);
			var imgPath = "";
			
			if( ext == "jpg" || ext =="png" || ext =="gif" || ext =="tiff") {
				imgPath = imgurl;
			}else if( ext =="zip" || ext =="gz" || ext =="tar" || ext =="rar" || ext =="iso") {
				imgPath = siteurl+"filetype_zip.png";
			}else if(ext =="xlsx" || ext =="xls") {
				imgPath = siteurl+"filetype_zip.png";
			}else if(ext =="doc" || ext =="docx") {
				imgPath = siteurl+"doc_filetype.png";
			}else if(ext =="pdf") {
				imgPath = siteurl+"filetype_pdf.png";
			}else {
				imgPath = siteurl+"default.png";
				
			} 
			
			$('#'+formfield+"_img").html('<img src="'+imgPath+'" width="100" /><a class="delimg" data-value="'+ ElementIndex[1] +'">&nbsp;</a>');
			t('#'+formfield+"_attachementID");
			$('#'+formfield+"_attachementID").val(imgID);
			t($('#'+formfield+"_attachementID").html())
		}
	}
	
	jQuery(".field_type_options").change(function(){
			var fieldName = $(":selected",this).html();	
			var fieldNameType = $(this).val();	
			var fieldID = $(this).attr("data-value");
		
			var countIndex = "new_"+$(".frm_edit_view #sortable li").length;
			var returnVal = '<ul class="form_fields">';
			if(fieldName != "Linebreak") {
				returnVal += '<li name="lblTitle">';
				returnVal += '<label>Title</label>';
				returnVal += '<div id="field">';
				returnVal += '<input type="text" class="title validate[required]" id="title" name="title['+countIndex+']" maxlength="50" />';
				returnVal += '</div></li>';
			}
			
			if(fieldName != "Editor" && fieldName != "Linebreak" && fieldName != "Editor Lite") {
				returnVal += '<li name="lblDesc">';
				returnVal += '<label>Description</label>';
				returnVal += '<div id="field"><input type="text" name="description['+countIndex+']" /></div>';
				returnVal += '</li>';
			}
			
			if(fieldName == "YesNo") {
				returnVal += '<li name="lblSettings">';
				returnVal += '<label>Label 1</label><div id="field"><input type="text" name="label['+countIndex+'][1]" value="Yes"/>';
				returnVal += '</div></li>';
				returnVal += '<li name="lblSettings">';
				returnVal += '<label>Label 2</label><div id="field"><input type="text" name="label['+countIndex+'][0]" value="No"/>';
				returnVal += '</div></li>';
			
			}
			
			returnVal += '</ul>';
			returnVal += '<input type="hidden" name="vum_index['+countIndex+']" value="'+countIndex+'"/>';
			returnVal += '<input type="hidden" name="new_field['+countIndex+']" value="1"/>';
			returnVal += '<input type="hidden" name="field_type['+countIndex+']" value="'+fieldNameType+'"/>';
			
			
			$(".frm_edit_view #sortable").append('<li id="'+countIndex+'"><div class="postbox" id="pageparentdiv" style="display: block;"><div title="Click to toggle" class="handlediv"><br></div><h3 class="hndle">'+fieldName+': <span id="frmTitle"></span></h3><div class="inside">'+returnVal+' <p><a class="del_field" data-value="'+countIndex+'">Delete</a> | <a class="close_field">close</a></p></div></div></li>');
			
		var sortedIDs = $( "#sortable" ).sortable( "toArray" ).toString();
		$(".fornIDs").val(sortedIDs);
		//reset the option value
		$(this).prop('selectedIndex',0);
			//$("#formContainer_"+fieldID).html(returnVal);
			 
	});
	
	$(".delimg").live("click",function(){
		var thisID = $(this).attr("data-value"); //wpm_vumHP_formData_18
		$("#wpm_vumHP_formData_" + thisID).val("");
		$("#wpm_vumHP_formData_" + thisID+"_img").html("");
	});
	
	$("#wpm_form").live("submit",function(){
		$(this).attr("disabled","disabled");
		$(".ajax-loading").css("visibility","visible");

	});
	$(".del_field").live("click",function(){
		var fieldID = $(this).attr("data-value");
		var parentElement = $(this).parent().parent();
		var custom_attachment = $("#wp_custom_attachment").attr("name");
		$(this).parent().hide();
		$(".ajax-loading").css("visibility","visible");
		$(".button-primary").attr("disabled","disabled");
		findID = fieldID.search("new_");
		
		if(eval(findID) == 0){
			parentElement.parent().remove();
			$(".ajax-loading").css("visibility","hidden");
			$(".button-primary").removeAttr("disabled");
			return false;
		}
		
			$.ajax({
			 type : "post",
			 dataType : "json",
			 url : ajaxurl,
			 data : {action: "vumh_delete_field",fieldID: fieldID},
			 success: function(response) {
				if(response.status == "1") {
					$(".ajax-loading").css("visibility","hidden");
					$(".button-primary").removeAttr("disabled");
					parentElement.parent().remove();
				}
			 }
		  }) 
	});
	
	
	$('input[name$="edit_view_submit"]').click(function(){
/*		
		if($('#wpm_form input[name$="title"]').val() ==""){
		alert("Title is required");	
		return false;
		}*/
	})
	// Form validation
	$(".frm_edit_view").validationEngine();
	$(".frm_global_settings").validationEngine();
	
	$("#sortable").sortable({update: function(event, ui) {
		var sortedIDs = $( "#sortable" ).sortable( "toArray" ).toString();
		$(".fornIDs").val(sortedIDs);
		},
		handle: ".postbox .hndle"
	});
	
	
	$(".frm_edit_view .handlediv").live("click",function(){
		var MainFRMContainer = $(this).parent().find(".inside");	
		MainFRMContainer.toggle("slow");
	});
	
	$(".frm_edit_view .close_field").live("click",function(){
		var MainFRMContainer = $(this).parent();	
		console.log(MainFRMContainer.html());
		MainFRMContainer.toggle("slow");
	});
	
	$(".frm_edit_view .title").live("keyup",function(){
		$(this).parents("#pageparentdiv").find("#frmTitle").html( $(this).val());
	});
	
	$(".vumhp_remove_page").live("click",function(){
		$(this).parent().remove();
		return false;
	});
	
	$(".vumhp_add_page").live("click",function(){
		//$(this).parent().parent().find("p:first").clone().appendTo('#subpages_container');
		var countvumhp_pages = $(".vumhp_pages").length;
		var activeCountPages = eval(countvumhp_pages + 1);
		$('#subpages_container').append('<p><input type="text" class="vumhp_pages validate[required]" name="vumhp_pages[new]['+activeCountPages+']" value="" /><a href="#" class="vumhp_remove_page"><img src="'+siteurl+'xit.gif" border="0"></a></p>');
		return false;
	});
	$(".sectionLinkOpt").change(function(){
		
		if($(this).val() == "Other") $(this).next("input").show();
		else
		$(this).next("input").hide();
	});
	
});

function t(str){
	console.log(str);
}
		 