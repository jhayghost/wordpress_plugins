<?php
class vumHp_formGenerator
{
	var $homepageData 		= array(); 				//format [index]=>[name, type, attr[], value, title, required, subpage]
	var $fields 			= array("Input"=>"Input",
									"YesNo"=>"YesNo",
									"Textarea"=>"Textarea",
									"Fileupload"=>"Fileupload",
									"Editor"=>"Editor",
									"Editor_Lite"=>"Editor Lite",
									"Linebreak"=>"Linebreak",
									"Section"=>"Section",
									"Section_image"=>"Section + Image"
									);
									
									/*
									"Dropdown"=>"Dropdown",
									"RadioGroup"=>"RadioGroup",
									*/
	var $subpageFields_Array		= array();
	var $subpage = '1';
	function __construct()
	{
		$this->get_HomepageData(); // get all homepage data
	}
	private function get_HomepageData() {
		global $wpdb, $vum_homepage;
		$wpm_vumHP_installed = get_option( 'wpm_vumHP_installed');
		if($wpm_vumHP_installed == '1'){
			$query = "SELECT * FROM ".$wpdb->prefix."vumhp_fields ORDER BY vum_index";
			$rows = $wpdb->get_results($query);
			if(count($rows)>0) {
				foreach($rows as $row) {
					
					$this->homepageData[$row->id] = array(	"title" => $row->title,
															"name" => $row->name,
															"description"=>$row->description,
															"label" => $row->label,
															"value" => $row->value,
															"vum_index"=> $row->vum_index,
															"subpage" => $row->subpage,
															"type" => $row->type);
															
					$subpage = ($row->subpage=="" || empty($row->subpage) )? 1 : $row->subpage;
					
					$this->subpageFields_Array[ $subpage ][ $row->id ] = $row->value;
					if($row->type == 'Section' || $row->type == 'Section_image') {
						
							$vum_homepage[$row->id]['link'] = '';
							$vum_homepage[$row->id]['title'] = '';
							$vum_homepage[$row->id]['description'] = '';
							if( $row->type == 'Section_image') {
								$vum_homepage[$row->id]['image'] = '';
								$vum_homepage[$row->id]['path'] = '';
								$vum_homepage[$row->id]['attachedID'] = '';
							}
							
						if($row->value!==""){
							
							$sectionValue = json_decode($row->value);
							if(count($sectionValue)){
							if($sectionValue->selectionVal =='Other') {
								$titlehref = $sectionValue->link;
							}elseif($sectionValue->selectionVal !='' && $sectionValue->selectionVal != 'No Link'){
								$titlehref = $sectionValue->selectionVal;
							}else{
								$titlehref = '';
							}
							
							$vum_homepage[$row->id]['link'] = $titlehref;
							
							//{"valTitle":"asdfasdf","selectionVal":"No Link","link":"23452345354","editorVal":"sadfasdf","upload":{"link":"http:\/\/localhost\/vumhomepage\/wp-content\/uploads\/2012\/11\/Capture.png","attachementID":"32"}}
							if($titlehref=="") {
								$vum_homepage[$row->id]['title'] = '<span class="vum_title vum_title'.$row->id.'>'.nl2br($sectionValue->valTitle).'</span>';// $vum_homepage[$row->id]['title'];
							}else{
								$vum_homepage[$row->id]['title'] = '<a href="' . $titlehref . '" class="vum_href vum_href'.$row->id.' title="'.$sectionValue->valTitle.'">'. nl2br($sectionValue->valTitle) .'</a>';
							}
							
							
									if(isset($sectionValue->upload)) {
										
										$checklink = get_extention_img($sectionValue->upload->link, TRUE);
										$imgpath = $sectionValue->upload->link;

										$vum_homepage[$row->id]['path'] = $imgpath;
										$vum_homepage[$row->id]['attachedID'] = $sectionValue->upload->attachementID;
										
									}else{
										unset($vum_homepage[$row->id]['image']);
									}
							
							$vum_homepage[$row->id]['description'] =  '<div class="vum_description vum_description'.$row->id.'">'.nl2br($sectionValue->editorVal).'</div>';
							}
							
						}
					} elseif($row->type == 'Fileupload') {
						$vum_homepage[$row->id]['path'] = "";
					
						if($row->value != ""){
								$sectionValue = json_decode($row->value);
							if(count($sectionValue)){
								$checklink = get_extention_img($sectionValue->link, TRUE);
					
								$imgpath = $filepath = $sectionValue->link;
								
								if(!$checklink['is_image']){
									$imgpath = $checklink["imagelink"];
									
								}
								
								$vum_homepage[$row->id]['path'] = $filepath;
							}
							
						}
					} else {
						$vum_homepage[$row->id] = '<div class="vum_value vum_value'.$row->id.'>'.nl2br($row->value).'</div>';
					}
				}
			}
		//	$vum_homepage = $this->homepageData;
		}
	}
	function get_row($index) {
		global $wpdb;
		$query = "SELECT * FROM ".$wpdb->prefix."vumhp_fields WHERE id = '$index'";
		return $wpdb->get_row($query);
	}
	
	function get_rows() {
		global $wpdb;
		$query = "SELECT * FROM ".$wpdb->prefix."vumhp_fields";
		return $wpdb->get_results($query);
	}
	
	function get_value($index){
		return (! isset( $this->homepageData[$index] ) )? "" : $this->homepageData[$index]['value'];
	}
	
	function get_option($index, $var="value", $default = ""){
		if(! isset($this->homepageData[ $index ])) return $default;
		
		if(isset($this->homepageData[ $index ][ $var ])) {
			return $this->homepageData[ $index ][ $var ];
		} else {
			return $default;
		}
	}
	
	function sectionFields($index = "")
	{
		
		return $this->get_array_val($index, $this->subpageFields_Array);
	}
	
	function count_fields()
	{
		if(isset($this->subpageFields_Array[$this->subpage]))
		return count($this->subpageFields_Array[$this->subpage]);
		return 0;
	}
	
	function saveForm(){

		global $wpdb;
		//check if input type is file upload
		$data = array();
		
		/****
		 *
		 */
		
		/** client view */
		if(isset($_POST['client_form_submit'])) {
			if( isset( $_POST['wpm_vumHP_formData'] ) ) {
				foreach($_POST['wpm_vumHP_formData'] as $id => $vum_val) {
					$vum_val = stripslashes_deep($vum_val);
					if(is_array($vum_val)) $vum_val = json_encode($vum_val);
							$wpdb->update(  $wpdb->prefix."vumhp_fields", array("value"=>$vum_val),  
											array( 'id' => $id) ); 
				}
			}
		} else { 
			
			
			//Check if index is exist
			if(!isset($_POST['vum_index']))
			return false;
			
			
			
			/** Edit view */
			$index = 0;
			
			$fornIDs = explode(",",$_POST['fornIDs']);
			$fornIDs = array_flip($fornIDs);
			$newFieldsCount = 0;
			foreach($_POST['field_type'] as $id => $postdata)
			{
				$data["subpage"] = $this->subpage;
				
				if(!empty($_POST['field_type'][$id])) {
				$index++;
				
				$ordering = $fornIDs[ $id ];
				
				$data["vum_index"] = $ordering + 1;
				
				$data["type"] = $wpdb->escape($postdata);
			
			
					$data["title"] = "";
					if(isset($_POST['title'][$id])){
						$data["title"] = $wpdb->escape($_POST['title'][$id]);
						$data["name"] = $wpdb->escape($_POST['title'][$id]);
					}
					$data["description"] = "";
					if(isset($_POST['description'][$id])){
						$data["description"] = $wpdb->escape($_POST['description'][$id]);
					}
					$data["label"] = '';
					if(isset($_POST['label'][$id])){
						$data["label"] = json_encode($_POST['label'][$id]);
					}
					if($wpdb->escape($postdata) =="Linebreak") {
						$data["name"] = "_linebreak";
					}

					/* Save to database*/
					if(isset($this->homepageData[ $id ])) {
					//	unset($data["vum_index"]);
						$wpdb->update(  
										$wpdb->prefix."vumhp_fields", stripslashes_deep($data),  
										array( 'id' => $id)
									); 
					} else { 
					
						$wpdb->insert( $wpdb->prefix."vumhp_fields", $data);
					
					}
				}
			
			}
			$orders = 0;
			foreach($fornIDs as $formID){
				$orders++;
				
			}
			
		}
	}
	
	function get_array_val($index = "", $array = array()) {
		
		if(empty($index)) {
			return	$array;
		} else{
			if(isset($array[$index])) return $array[$index];
			else return "";
		}
	}
	
	function get_pages_rows(){
		global $wpdb;
		$query = "SELECT * FROM ".$wpdb->prefix."vumhp_pages";
		return $wpdb->get_results($query);
	}

}
