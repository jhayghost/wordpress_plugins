<?php

class VumHP_form
{
    var $fieldList, $navList, $topLvlTabs = 0, $formTitle,$actionPage;

    function  __construct($title='', $actionPage = '')
    {
        $this->formTitle=$title;
		 $this->actionPage = $actionPage;
    }
    function setPluginURL($url='')
    {
        $this->pluginURL = $url;
    }
    function addInput($id, $title, $desc, $default = '', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'textbox', $title, $id, $desc, array(), $default, $attributes);
    }
    function addFileupload($id, $title, $desc, $default = '', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'fileupload', $title, $id, $desc, array(), $default, $attributes);
    }
    function addSection($id, $title, $desc, $default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'section', $title, $id, $desc, array(), $default, $attributes );
    }
    function addSection_image($id, $title, $desc, $default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'sectionImage', $title, $id, $desc, array(), $default, $attributes );
    }
    function addEditor($id, $title, $desc, $default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'editor', $title, $id, $desc, array(), $default, $attributes );
    }
    function addEditor_Lite($id, $title, $desc, $default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'editorlite', $title, $id, $desc, array(), $default, $attributes );
    }
    function addYesNo($id,$title,$desc, $default = '1', $yesValue = 1, $values = array())
    {
		$options = array( $yesValue => 'Yes', 0 => 'No');
		if( count($values) > 0 )
		$options = $values;
		
        $this->addRadioGroup($id, $title, $desc, $options , $default );
    }
    function addDropdown($id,$title,$desc,$options=array(), $default = false, $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'dropdown', $title, $id, $desc, $options, $default, $attributes );
    }
	
    function addTextarea($id,$title,$desc,$default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'textarea', $title, $id, $desc, array(), $default, $attributes);
    }
	
    function addHidden($id,$title,$desc,$default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'hidden', $title, $id, $desc, array(), $default, $attributes);
    }
    function addMediaupload($id,$title,$desc,$default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'mediaupload', $title, $id, $desc, array(), $default, $attributes);
    }
    function addMediauploadSettings($id,$title,$desc,$default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'mediauploadSettings', $title, $id, $desc, array(), $default, $attributes);
    }
	
	function addLinebreak($id="",$title="",$desc="",$default='', $attributes = array())
    {
        $this->fieldList[$id] = $this->_array( 'linebreak', $title, $id, $desc, array(), $default, $attributes);
    }
	
    function addRadioGroup($id,$title,$desc,$options=array(), $default=false)
    {
        $this->fieldList[$id] = $this->_array( 'radio', $title, $id, $desc, $options, $default );
    }
    function localVideos()
    {
        $this->fieldList['local'] ='';
    }
    function addHeading($title, $tag = 'h2' )
    {
        $this->fieldList[] = $this->_array ('title', $title, $tag );
    }
    function html($html)
    {
        $this->fieldList[] = $this->_array('html', $html);
    }
    function addClass($fieldId, $class)
    {
        $this->fieldList[ $fieldId ] [ 'classes' ] [] = $class;
    }
	
    function htmlcode($html)
    {
        $this->fieldList[] = $this->_array('htmlcode', '', 0, '', '', $html );
    }
	
	function openSection($id){
		$this->fieldList[] = $this->_array ('sectionOpen', '', $id);
	}
	
	function openForm($id = "wpm_form", $method = "POST")
	{
		$methodArr = array('attributes'=>$method,'class'=> $id);
		$this->fieldList[] = $this->_array ('openForm', $methodArr);
	}
    function closeForm($id = "")
    {
        $this->fieldList[] = $this->_array ('closeForm','',$id);
    }
    function closeSection()
    {
        $this->fieldList[] = $this->_array ('sectionClose');
    }
    function fields()
    {
        $return = array();

        foreach( $this->fieldList as $key => $val ):

                // Fields with an integer mean they're a heading, div etc. Not an input. 
                if( ! is_int($key) )
                    $return[$key] = $val;
                
        endforeach;

        return $return;
    }
    function display()
    {

        VumHP_form_html::title(array('title'=> '<img style="vertical-align: -7px;margin-right:7px" src="'. vumhp_get_titlepage_logo() .'">' . vumhp_get_plugin_name_title(),'id' => 'h2') );
        VumHP_form_html::tabNav( $this->navList );
		
        foreach($this->fieldList as $key=>$item ):
                VumHP_form_html::$item['type']($item);
        endforeach;
		
		VumHP_form_html::sectionClose();
    }
    function _array($type='', $title='', $id=0, $desc='', $options=array(), $default=false, $attributes = array())
    {
		$dbName = explode("[",$id);
        $ar = array(
            'type'=>$type,
            'title'=>$title,
            'id'=> $id,
            'desc'=>$desc,
            'value'=> $default,
            'options'=>$options,
            'dbName' => $dbName[0],
            'classes' => array(),
			'attributes' => $attributes,
			
        );
        return $ar;
    }
}

class VumHP_form_html
{
    function openForm($atts= array())
    {
        extract($atts);
		?>
        <div class="wrap">
        <form id="wpm_form" method="<?php echo $title['attributes'];?>" class="<?php echo $title['class'];?>" enctype="multipart/form-data" <?php echo self::get_attributes($attributes)?>>
        <?php wp_nonce_field('vum_nonce','vum_save'); ?>
        <?php }

    function closeForm($atts)
    {
        extract($atts);
		if(empty($id)) $id = "submit-button";
		?><div id="publishing-action"><p class="submit"><?
        echo '<input type="submit" accesskey="p" tabindex="5" name="'.$id.'" class="button-primary" id="publish" value="Save Changes" /><img alt="" id="ajax-loading" class="ajax-loading" src="'. site_url("/wp-admin/images/wpspin_light.gif").'"></p></div>';
        echo '<input type="hidden" name="return" class="return" value="" />';
        echo '</form>';
        echo '</div>'; // Close #wrap
    }
    function tabNav($atts=array())
    {   
		$currentpage = isset($_GET['vum_page'])? $_GET['vum_page']: "clientview";
		$curpage = isset($_GET['page'])? $_GET['page']: "vumhp_form_view";
	?><div id="tabs" class="vumhp_container">
      	<ul id="topnav">
            <?php foreach($atts as $id=>$navItem): ?>
			<li<?php echo ($navItem['link'] == $currentpage )? ' class="selected"':''?>><a href="<?php echo site_url("wp-admin/admin.php?page=".$curpage."&vum_page=" . $navItem['link'])?>"><?php echo $navItem['title'];?></a></li>
            <?php endforeach; ?>
		</ul><br />
    <?php }
	
    function textbox($atts)
    {
        extract($atts); ?>
            <div class="wpm_input wpm_text">
            	<?php if($title!=""){?>
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <?php }?>
                <div class="wpm_form_item <?php echo $id; ?>">
                    <input name="<?php echo $id; ?>" type="text" value="<?php echo $value; ?>"<?php echo self::get_attributes($attributes)?>/><br />
                    <small><?php echo $desc; ?></small>
                </div>
            </div>
    <?php }
    function fileupload($atts)
    {
        extract($atts); ?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item <?php echo $id; ?>">
                <input type="file" id="wp_custom_attachment"  name="<?php echo $id; ?>"<?php echo self::get_attributes($attributes)?>/><br />
                <small><?php echo $desc; ?></small><br />
                    <small><?php echo ($value)? '<a href="'.$value.'" target="_blank">'.$value.'</a>&nbsp;&nbsp;<a class="delimg"><img rel="'.$value.'" src="'.WPDEV_PLUGIN_URL.'/images/xit.gif"/></a>':''; ?></small>
                </div>
            </div>
    <?php }
	function linebreak($atts) {
		echo "<hr />";
	}
    function hidden($atts)
    {
        extract($atts); ?><input name="<?php echo $id; ?>" class="<?php echo $id; ?>" type="hidden" value="<?php echo $value; ?>"<?php echo self::get_attributes($attributes)?>/>
    <?php }
    function textarea($atts)
    {
        extract($atts); ?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item <?php echo $id; ?>">
                    <textarea name="<?php echo $id; ?>"<?php echo self::get_attributes($attributes)?>><?php echo $value; ?></textarea><br />
                    <small><?php echo $desc; ?></small>
                </div>
            </div>
    <?php }
    function mediaupload($atts)
    {
        extract($atts);
		$filelink = "";
		$attachementID = "";
		if($value!="") {
			if($dbvalue = json_decode($value)){
				$filelink = $dbvalue->link;
				$attachementID = $dbvalue->attachementID;
			}
			
		}
		?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item <?php echo $id;
				$attributes2 = $attributes;
				$attributes2['class'] = "fileuploader_input";
				?>">
                    <input name="<?php echo $id; ?>[link]" id="<?php echo str_replace(array("[","]"), array("_",""), $id); ?>" type="text" value="<?php echo $filelink; ?>"<?php echo self::get_attributes($attributes2)?>/><input id="<?php echo $id; ?>_button"<?php echo self::get_attributes($attributes)?> type="button" value="Upload" />
                     <input name="<?php echo $id; ?>[attachementID]" type="hidden" id="<?php echo str_replace(array("[","]"), array("_",""), $id); ?>_attachementID" value="<?php echo $attachementID?>" />
                    <br />
                    <small><?php echo $desc; ?></small>
                </div>
            </div>
    <?php }
	
    function mediauploadSettings($atts)
    {
        extract($atts); ?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item <?php echo $id;
				$attributes2 = $attributes;
				$attributes2['class'] = "fileuploader_input";
				?>">
                    <input name="<?php echo $id; ?>" id="<?php echo str_replace(array("[","]"), array("_",""), $id); ?>" type="text" value="<?php echo $value; ?>"<?php echo self::get_attributes($attributes2)?>/><input id="<?php echo $id; ?>_button"<?php echo self::get_attributes($attributes)?> type="button" value="Upload" /><br />
                    <small><?php echo $desc; ?></small>
                </div>
            </div>
    <?php }
    function sectionImage($atts)
    {
	        extract($atts);
			$ins['tinymce']['theme_advanced_buttons1']='bold, italic, link, unlink';
			$ins['tinymce']['theme_advanced_buttons2']='';
			$ins['tinymce']["height"] = 200;
			$ins["quicktags"] = false;
			$ins["media_buttons"] = false;
				$args = array(
					'sort_order' => 'ASC',
					'sort_column' => 'post_title',
					'hierarchical' => 1,
					'exclude' => '',
					'include' => '',
					'meta_key' => '',
					'meta_value' => '',
					'authors' => '',
					'parent' => -1,
					'exclude_tree' => '',
					'number' => '',
					'offset' => 0,
					'post_type' => 'page',
					'post_status' => 'publish'
				); 
		
		$pages = get_pages($args);
		$editorVal = "";
		$selectionVal = "";
		$upload = "";
		$link = "";
		$valTitle = "";
		$fileID = "";
		$filelink = "";
		if( $value != "" ) {
			$val = json_decode($value);
			$valTitle = $val->valTitle;
			$editorVal = $val->editorVal;
			$link = $val->link;
			$selectionVal = $val->selectionVal;
			if(isset($val->upload->link)) {
				$upload = $filelink = $val->upload->link;
				$fileID = $val->upload->attachementID;
			}

		}
		?>
            <div class="wpm_input wpm_text">
                <label><?php echo $title; ?> Title</label>
                <div class="wpm_form_item">
                <input name="<?php echo $id; ?>[valTitle]" type="text" value="<?php echo $valTitle; ?>"/>
                </div>
            </div>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?> Title Links To: </label>
                <div class="wpm_form_item">
                 <select name="<?php echo $id; ?>[selectionVal]" class="sectionLinkOpt">
                 			<option value="No Link"<?php if(("No Link" == $selectionVal) || ($selectionVal=='')){echo' selected="selected"';} ?>>No Link</option>
                 			<option disabled="disabled" value="-----">-----</option>
                 			<option value="Other"<?php if("Other" == $selectionVal){echo' selected="selected"';} ?>>Other</option>
                 			<option disabled="disabled" value="-----">-----</option>
                            <?php foreach($pages as $page): ?>
                            <option value="<?php echo get_permalink( $page->ID );?>"<?php if( get_permalink( $page->ID) == $selectionVal){echo' selected="selected"';} ?>><?php echo $page->post_title;?></option>
                            <?php endforeach; ?>
                    </select>
                    <input name="<?php echo $id; ?>[link]" type="text"  class="sectionLink" value="<?php echo $link; ?>"  style="width:241px;<?php echo ( $selectionVal!='Other') ? ' display:none"':''?>"/>
	                <br clear="all" />
                    <?php wp_editor(nl2br($editorVal), $id.'[editorVal]', $ins);?>
                    </div>
            </div>
             <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item <?php echo $id;?>">
                    <input name="<?php echo $id; ?>[upload][link]" id="<?php echo str_replace(array("[","]"), array("_",""), $id); ?>" type="text" value="<?php echo $upload; ?>"/><input id="<?php echo $id; ?>_button" class="fileuploader_input fileuploader" type="button" value="Upload" />
                    <input name="<?php echo $id; ?>[upload][attachementID]" type="hidden" id="<?php echo str_replace(array("[","]"), array("_",""), $id); ?>_attachementID" value="<?php echo $fileID;?>" />
                </div>
            </div>
            <?php
			$index = str_replace(array("wpm_vumHP_formData[","]"), array("",""),$id);
			
			if( $fileID != "") {
				$thumb_url = wp_get_attachment_image_src( $fileID, 'thumbnail', true );								
				$filelink = $thumb_url[0];
			}
			
            echo '<div id="'. str_replace(array("[","]"), array("_",""), $id) .'_img" class="imgcontainer">'. (($upload!="")? '<img src="'. get_extention_img( $filelink ).'" width="100"><a class="delimg" data-value="'. $index .'">&nbsp;</a>' : '' ) .'</div>';
			?>
            <hr/>
    <?php }
    function section($atts)
    {
	        extract($atts);
			$ins['tinymce']['theme_advanced_buttons1']='bold, italic, link, unlink';
			$ins['tinymce']['theme_advanced_buttons2']='';
			$ins['tinymce']["height"] = 200;
			$ins['tinymce']["forced_root_block"] = "p";
			$ins["quicktags"] = false;
			$ins["media_buttons"] = false;
			
				$args = array(
					'sort_order' => 'ASC',
					'sort_column' => 'post_title',
					'hierarchical' => 1,
					'exclude' => '',
					'include' => '',
					'meta_key' => '',
					'meta_value' => '',
					'authors' => '',
					'parent' => -1,
					'exclude_tree' => '',
					'number' => '',
					'offset' => 0,
					'post_type' => 'page',
					'post_status' => 'publish'
				); 
		
		$pages = get_pages($args);
		$editorVal = "";
		$selectionVal = "";
		$link = "";
		$valTitle = "";
		if( $value != "" ) {
			$val = json_decode($value);
			if(count($val)) {
				$valTitle = $val->valTitle;
				$editorVal = $val->editorVal;
				if(isset($val->link))
				$link = $val->link;
				$selectionVal = $val->selectionVal;
			}
		}
		?>
            <div class="wpm_input wpm_text">
                <label><?php echo $title; ?> Title</label>
                <div class="wpm_form_item">
                <input name="<?php echo $id; ?>[valTitle]" type="text" value="<?php echo $valTitle; ?>"/>
                </div>
            </div>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?> Title Links To: </label>
                <div class="wpm_form_item">
                 <select name="<?php echo $id; ?>[selectionVal]" class="sectionLinkOpt">
                 			<option value="No Link"<?php if(("No Link" == $selectionVal) || ($selectionVal=='')){echo' selected="selected"';} ?>>No Link</option>
                 			<option disabled="disabled" value="-----">-----</option>
                 			<option value="Other"<?php if("Other" == $selectionVal){echo' selected="selected"';} ?>>Other</option>
                 			<option disabled="disabled" value="-----">-----</option>
                            <?php foreach($pages as $page): ?>
                            <option value="<?php echo get_permalink( $page->ID);?>"<?php if(get_permalink( $page->ID ) == $selectionVal){echo' selected="selected"';} ?>><?php echo $page->post_title;?></option>
                            <?php endforeach; ?>
                    </select>
                    <input name="<?php echo $id; ?>[link]" type="text"  class="sectionLink" value="<?php echo $link; ?>" <?php echo ( $selectionVal!='Other') ? ' style="display:none"':''?>/>
                <br clear="all" />
                    <?php wp_editor(nl2br($editorVal), $id.'[editorVal]', $ins);?>
                    <small><?php echo $desc; ?></small>
                    </div>
            </div>
            <hr/>
    <?php }
    function editor($atts)
    {
	        extract($atts);
			$ins["height"] = 200;
			$ins["quicktags"] = true;
			$ins["media_buttons"] = true;
			
		?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label><br clear="all" /><div class="wpm_form_item">
                    <?php wp_editor($value, $id, $ins);?>
                    <small><?php echo $desc; ?></small>
                    </div>
            </div>
    <?php }
    function editorlite($atts)
    {
        extract($atts);
		//add_filter('tiny_mce_before_init', 'CustomformatTinyMCE' );
		
		$in['tinymce']['theme_advanced_buttons1']='bold, italic, link, unlink';
		$in['tinymce']['theme_advanced_buttons2']='';
		$in["quicktags"] = false;
		$in["media_buttons"] = false;
		$ins['tinymce']["height"] = 200;
			
		?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?></label><br clear="all" /><div class="wpm_form_item">
                    <?php wp_editor(nl2br($value), $id, $in);?>
                    <small><?php echo $desc; ?></small>
                    </div>
            </div>
    <?php }
     function dropdown($atts)
    {
        extract($atts); ?>
            <div class="wpm_input wpm_text">
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item">
                    <select name="<?php echo $id; ?>"<?php echo self::get_attributes($attributes)?>>

                            <?php foreach($options as $k=>$v): ?>
                            <option value="<?php echo $k;?>"<?php
                            if(is_array($value)) {
								if( in_array($k , $value) ){ echo' selected="selected"';}
							} else {
								if($k == $value){echo' selected="selected"';}
							}
                            ?>><?php echo $v;?></option>
                            <?php endforeach; ?>
                    </select>
                    <?php if ($id == 'num_local') { ?>
                    <img id="wpm-waiting" src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ); ?>" alt="" />
                    <?php } ?>
                    <small><?php echo $desc; ?></small>
                </div>
            </div>
    <?php }
     function radio($atts)
    {
        extract($atts); ?>
            <div class="wpm_input wpm_text" id="wpm_o_<?php echo $id; ?>">
                
                <label for="<?php echo $id; ?>"><?php echo $title; ?>: </label>
                <div class="wpm_form_item wpm_form_radio_container">
                    <?php 
					if(count($options) > 0) {
						foreach($options as $k=>$v): ?>
						<label><input type="radio" name="<?php echo $id; ?>" value="<?php echo $k;?>" <?php
							if($k == $value){echo' checked="checked" ';}
							?> />
							<?php echo $v; ?>
							</label>
						<?php
						endforeach; 
					}?>
					<br />
                    <small><?php echo $desc; ?></small>
                </div>
            </div>
    <?php }

    function title($atts)
    {
        extract($atts); ?>
        <<?php echo $id;?>><?php echo $title;?></<?php echo $id;?>>
    <?php
    }

    function sectionOpen($atts)
    {
        extract($atts); ?>
        <div class="wpm_section <?php self::applyClasses($classes);?>" <?php echo 'id="'.$id.'"';  ?>>
        <?php
    }

    function applyClasses($classArray=array())
    {
        foreach($classArray as $class):
            echo ' ' . $class ;
        endforeach;
    }

    function html($atts)
    {
        echo $atts['title'];
    }
    function htmlcode($atts)
    {
        extract($atts);
        echo $atts['value'];
    }

    function sectionClose($atts = NULL)
    {
        echo '</div>';
    }
	function get_attributes($val = NULL) {
		$return = "";
		if(is_null($val)) return "";
		foreach($val as $name => $value) {
			$return .= " ".$name.'="'.$value.'"';
		}
		return $return;
	}
}
