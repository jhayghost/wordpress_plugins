<?php

if ( ! defined( 'updaterLocation' ) )
define( "updaterLocation", "#");

if ( ! defined( 'WPDEV_PLUGIN_DIR' ) )
	define( 'WPDEV_PLUGIN_DIR', untrailingslashit( dirname( __FILE__ ) ) );
	
if ( ! defined( 'WPDEV_PLUGIN_URL' ) )
	define( 'WPDEV_PLUGIN_URL', untrailingslashit( plugins_url( '', __FILE__ ) ) );

$vum_homepage = array();
	
class Vum_hp{

    const pluginver     = '0.4';
    var $form, $formPrefs, $WPLang, $pluginURL, $_message,$errors,$messages; // Holds the form data
	var $visible_global_settings = 1; // 0 => false, 1=> true
	var $currentPage = 1;
	var $formGenerator;
	
    function __construct() {
		global $vum_homepage;
		//activating this plugin
		
        register_activation_hook( __FILE__, array(&$this, 'install' ) );		
		
		// This is the model of this plugin
		require_once("vumHp_formGenerator.class.php");		
		$this->formGenerator = new vumHp_formGenerator();
		
        // URL of the plugin folder, used from within views etc.
        $this->pluginURL = plugins_url( '', __FILE__ );
		
		//Load all necessary actions
        add_action('admin_menu', array(&$this,'add_pages') );
        add_action('admin_init', array(&$this, 'admin_init') );
		
		//Shortcode
		add_shortcode( 'homepagecreator', array(&$this, 'short_code') );
    }

    function admin_init() {
		 // Register the all javascript resources
		wp_enqueue_script( 'media-upload' );
		wp_enqueue_script( 'thickbox' );
		wp_register_script( 'vumhp_js', plugins_url( 'js/script.js' , __FILE__ ), array('jquery','media-upload','thickbox') );
		wp_register_script( 'jquery_validationEngine_en', plugins_url( 'js/jquery.validationEngine-en.js' , __FILE__ ), array( 'jquery' ) );
		wp_register_script( 'jquery_validationEngine', plugins_url( 'js/jquery.validationEngine.js' , __FILE__ ), array('jquery'));
        wp_enqueue_script( array( 'jquery', 'jquery-ui-tabs', 'jquery_validationEngine_en', 'jquery_validationEngine','jquery-ui',"jquery-ui-sortable","vumhp_js" ) );
		
        // Register the style
        wp_enqueue_style( 'thickbox' );
		wp_register_style( 'vumhpcss', plugins_url( 'style.css' , __FILE__ ), array(), self::pluginver );
        wp_register_style( 'validationEngine', plugins_url( 'css/validationEngine.jquery.css' , __FILE__ ), array(), self::pluginver );
        wp_enqueue_style( 'validationEngine' );
		
		add_action( 'wp_ajax_vumh_delete_field', array(&$this,'vumh_delete_field') );
		
    }
	/**
	 * Admin Menu
	 * @return null;
	 **/
    function add_pages() {
		
		// Return once user role is subscriber
		if( strtolower( vumhp_get_current_user_role() ) == "subscriber" )
			return;
		if( vumhp_can_edit_view() ){
			
			//Get all current plugin pages
			$pages = $this->formGenerator->get_pages_rows();	
			 
			//Add Plug-in Menu
			 // Add default menu
			$pluginname = (get_option("wpm_vumHP_plugin_name")!="")?get_option("wpm_vumHP_plugin_name") : "Homepage";
			$view_page = add_menu_page(
										$pages[0]->title,
										$pluginname,
										'read',
										"vumhp_form_view",
										array(&$this,'form_view'),
										vumhp_get_menu_logo(),
										'2.2' );
										
			//Check all sub-pages and add to plugin submenu
					if( count( $pages ) > 0 ) {
						$loadpage = array();
						foreach( $pages as $page ) {
							if( $page->id == "1" ) {
							$loadpage[ $page->id ] = add_submenu_page(
																	"vumhp_form_view",
																	ucfirst($page->title),
																	ucfirst($page->title),
																	'read',
																	"vumhp_form_view",
																	array(&$this,'form_view')
																);
							
							} else {$loadpage[ $page->id ] = add_submenu_page(
																	"vumhp_form_view",
																	ucfirst($page->title),
																	ucfirst($page->title),
																	'read',
																	"vumhp_form_view_".$page->id,
																	array(&$this,'form_view')
																);
							}
							if( isset( $_GET['page'] ) && $_GET['page'] == "vumhp_form_view_" . $page->id ){
								
								//set active page
								$this->currentPage 				= $page->id;
								$this->formGenerator->subpage 	= $this->currentPage;
								$this->visible_global_settings 	= 0;					// if active page is subpage only disable global setting
								$view_page 						= $loadpage[ $page->id ];
								
							}
						}
					}
			 
			 add_action('load-' . $view_page, array(&$this, 'admin_preload') );
			 
		}
    }
	
    function install() {
		ob_start();
		global $wpdb;
		$wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . "vumhp_fields" );
		$wpdb->query( "CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "vumhp_fields` (
						  `id` bigint(20) NOT NULL AUTO_INCREMENT,
						  `vum_index` int(11) DEFAULT NULL,
						  `title` varchar(255) DEFAULT NULL,
						  `name` varchar(255) DEFAULT NULL,
						  `description` varchar(255) DEFAULT NULL,
						  `label` varchar(255) DEFAULT NULL,
						  `settings` longtext,
						  `value` longtext,
						  `type` text,
						  `subpage` bigint(20) DEFAULT '1',
						  PRIMARY KEY (`id`)
						);" );
		$wpdb->query( "DROP TABLE IF EXISTS `". $wpdb->prefix ."vumhp_pages`" );
								
		$wpdb->query( "CREATE TABLE `". $wpdb->prefix ."vumhp_pages` (
						  `id` bigint(20) NOT NULL AUTO_INCREMENT,
						  `name` varchar(300) DEFAULT NULL,
						  `title` varchar(300) DEFAULT NULL,
						  `ordering` bigint(20) DEFAULT NULL,
						  PRIMARY KEY (`id`)
						);" );
		$wpdb->insert( $wpdb->prefix."vumhp_pages", array( "name" => 'home_page', "title" => "Homepage", "ordering" => '1' ) );
		
        add_option( 'wpm_vumHP_plugin_name', 'Homepage' );
        add_option( 'wpm_vumHP_plugin_name_title', 'Homepage Title' );        
        add_option( 'wpm_vumHP_installed', '1' );
        add_option( 'wpm_vumHP_Plugin_menu', '' );
        add_option( 'wpm_vumHP_Plugin_title', '' );
        add_option( 'wpm_vumHP_formData', '' );
        add_option( 'wpm_vumHP_setting_visible', vumhp_current_userID() );
        add_option( 'wpm_vumHP_canview_role', array("2") );
		add_action( 'activated_plugin', array(&$this, 'save_error') );
		ob_end_clean();
    }
	
	function save_error() {
		update_option( 'plugin_error',  ob_get_contents() );
	}

    function admin_preload() {
		if (!class_exists('VumHP_form'))
			require_once('form.php' );
		
        wp_enqueue_style( 'vumhpcss' );
		
		add_action( 'admin_notices', array(&$this, 'admin_notices') );
		//add_action('admin_head', array(&$this, 'header_js'));
				
        /* If not posting - go away */
        if( !isset($_POST) || empty($_POST) )
            return;

        if( ! wp_verify_nonce($_POST['vum_save'],'vum_nonce') )
            wp_die('VUM Nonce Failed');

        /* Define the form array */
        $this->form = $this->form_view_define();
		
		/**
		  * Check User Saving Permission
		  */
		if( isset( $_POST['global_setting_submit'] ) && ! vumhp_can_edit_setting() )
			return;
		
		if( isset( $_POST['edit_view_submit'] ) && ! vumhp_can_edit_view() )
			return;
			
        global $wpdb;
		$message = 0;
		if( isset( $_POST['client_form_submit'] ) || isset( $_POST['edit_view_submit'] ) ){
			
		// Saving for Client View and Edit view
			
			$message = 2;
			if( isset( $_POST['client_form_submit'] ) ) {
				$message = 3;
			}else{
				if( isset( $_POST['title'] ) && $_POST['title'] == "" ){
					wp_redirect( remove_query_arg('message') . '&message=4' );
					exit;
				}
			}
			
			$this->formGenerator->saveForm();
			
		} else {
			
			$message = 1;
			
			//Global Setting Saving	
			foreach( $this->form->fields() as $key => $val ):
				
				if( isset( $_POST[ $val['dbName'] ] ) ):
				
						update_option( $val['dbName'], stripslashes_deep($_POST[ $val['dbName'] ]) );
						
			   endif;
			   
			endforeach;
			
			//Save Pages
			if( isset( $_POST['vumhp_pages'] ) ):
			
				$currentPageIDs = array();
				
				foreach( $_POST['vumhp_pages'] as $pageIndex => $pagePost ) {
					
					//insert new subpages
					if( $pageIndex == 'new' ) {
						foreach( $pagePost as $NewPageIndex => $newPagePost ) {
							if( $newPagePost!="" ){
								$title = stripslashes_deep( $newPagePost );
								$name = strtolower( str_replace( " ","_",$title ) );
								$insertIndex = $wpdb->insert( $wpdb->prefix."vumhp_pages", array( "name"=>$name, "title"=>$title,"ordering"=>$NewPageIndex ) );
								$currentPageIDs[] = $wpdb->insert_id;
							}
						}
					}else{
						
					//Update post
						$currentPageIDs[] = $pageIndex;
					
						$title = stripslashes_deep( $pagePost );
						$name = strtolower(str_replace(" ","_",$title));
						$wpdb->update( $wpdb->prefix."vumhp_pages", array("name"=>$name, "title"=>$title,"ordering"=>$pageIndex),  
										array( 'id' => $pageIndex)
									);
						
					}
				}
				
				$currentPageIDsstr = implode( ",", $currentPageIDs );
				$wpdb->query("DELETE FROM `".$wpdb->prefix."vumhp_pages`
							  WHERE ".$wpdb->prefix."vumhp_pages.id NOT IN  (". $currentPageIDsstr .")");
			endif;
		}
		
        if( isset( $_POST['return'] ) && $_POST['return'] ) {
			
			$url = explode("#", $_POST['return']);
            wp_redirect( remove_query_arg("message"). '&message='. $message."#".$url[1]);
			
		}else
            wp_redirect( remove_query_arg('message') . '&message=1');
        exit;
    }
	/**
	 * Initialize form HTML
	 * @return object 	#form html
	 */
	function form_view_define() 
	{
		global $vum_homepage;
		$form = new VumHP_form( 'Homepage2', 'form_view' );
		$form->setPluginURL($this->pluginURL);
		$form->navList = array();
		
		if( vumhp_can_edit_view() ) {
			$form->navList[] = array("title"=> 'Client View', "link" => "clientview");
		}
		if( vumhp_can_edit_setting() ) {
			$form->navList[] = array("title"=> 'Edit View', "link" => "editview");
			if($this->visible_global_settings == 1 ) {
				$form->navList[] = array("title"=> 'Global Settings', "link" => "settingsview");
			}
		}

		//Client View Tab
        if( vumhp_can_edit_view() && (!isset($_GET['vum_page'])|| (isset($_GET['vum_page']) && $_GET['vum_page'] == "clientview"))) {
			if(count($this->formGenerator->homepageData)){
				$sectionFields = $this->formGenerator->sectionFields();
				
				if(isset($sectionFields[$this->formGenerator->subpage])) {
					$form->htmlcode('<div id="clientview_container">');
					$form->openForm();
					$mainSection = $sectionFields[$this->formGenerator->subpage];
					//asort($mainSection);
					if(count($mainSection)) {
						foreach( $mainSection as $index => $val ) {
							$dbType = $this->formGenerator->get_option($index,"type");
							$typesFlips = array_flip($this->formGenerator->fields);
							$inputType = (in_array($dbType, $typesFlips) )? $this->formGenerator->get_option($index,"type"): "Input";
							$objType = "add".$inputType;
							
							if($inputType == "YesNo") {
							$form->$objType( "wpm_vumHP_formData[". $index ."]", 
											 $this->formGenerator->get_option($index,"title"),
											 $this->formGenerator->get_option($index,"description"),
											 $this->formGenerator->get_option($index,"value"),
											 1,
											 json_decode($this->formGenerator->get_option($index,"label")));
							}elseif($inputType == "Linebreak") {
								$form->addLinebreak();
							}elseif($inputType == "Fileupload") {
								$form->addMediaupload("wpm_vumHP_formData[". $index ."]",
											$this->formGenerator->get_option($index,"title"),
											$this->formGenerator->get_option($index,"description"),
											$this->formGenerator->get_option($index,"value"), array("class"=>"fileuploader"));
								$filelink = "";
								$fileID = "";
									if($this->formGenerator->get_option($index,"value")!="") {
										$dbvalue = json_decode($this->formGenerator->get_option($index,"value"));
										$filelink = $dbvalue->link;
										$fileID = $dbvalue->attachementID;
									}
									
								if($fileID!="") {
									$thumb_url = wp_get_attachment_image_src( $fileID, 'thumbnail', true );								
									$filelink = $thumb_url[0];
								}
								
								$form->htmlcode('<div id="wpm_vumHP_formData_'.$index.'_img" class="imgcontainer">' . (($filelink!="")? '<img src="'. get_extention_img( $filelink ).'" width="100"><a class="delimg" data-value="'. $index .'">&nbsp;</a>' : '' ) . '</div>');
							}else {
								$form->$objType("wpm_vumHP_formData[". $index ."]",
												$this->formGenerator->get_option($index,"title"),
												 $this->formGenerator->get_option($index,"description"),
												$this->formGenerator->get_option($index,"value"));
							}
							
						}
					}
					$form->closeForm("client_form_submit");
					$form->htmlcode('</div>');
				}
			}		

		
		}elseif( vumhp_can_edit_setting() && (isset($_GET['vum_page']) && $_GET['vum_page'] == "editview")) { 
//Edit View Tab
			$form->htmlcode('<div id="editview_container">');
			$form->openForm("frm_edit_view");
			$select_fields = $this->formGenerator->fields;
			$select_fields[""] = " Please Select ";
			asort($select_fields);

					$current_count_fields = $this->formGenerator->count_fields();
					$form->htmlcode('<ul id="sortable">');
					$fornIDs = array();
					$viewcondestr = "<h3>Code view</h3>";
					if($current_count_fields > 0) {
						foreach($this->formGenerator->subpageFields_Array[$this->currentPage] as $index=>$formData) {
							$fornIDs[] = $index;
							$title = $this->formGenerator->get_option($index,"title");
							if( $this->formGenerator->get_option($index,"type") == "Linebreak")
							$title = "Linebreak";
								$viewcondestr .= "<strong>".$title.'</strong>';
								
								if($this->formGenerator->get_option($index,"type") == "Section" || $this->formGenerator->get_option($index,"type") == "Section_image" || $this->formGenerator->get_option($index,"type") == "Fileupload") {
									if(isset($vum_homepage[$index]) && count($vum_homepage[$index])) {
										foreach($vum_homepage[$index] as $varTitle => $varVal) {
											$viewcondestr .= '<br />vum_homepage('.$index.', "'.$varTitle.'"'. (($varTitle == "image")? ', "thumbnail"' : '') .');'. (($varTitle == "image")? ' // thumbnail, medium, large or full' : '');
										}
									}
								}else{
										$viewcondestr .= '<br />vum_homepage('.$index.');';
								}
								
								$viewcondestr .= '<br /><br />';
								$dbType = str_replace("_", " ", $this->formGenerator->get_option($index,"type"));
								
								$form->htmlcode('<li id="'.$index.'">
								<div class="postbox " id="pageparentdiv" style="display: block;">
									<div title="Click to toggle" class="handlediv"><br></div>
									<h3 class="hndle">' . $dbType .': <span id="frmTitle">'. $this->formGenerator->get_option($index,"title") . '</span></h3>
									<div class="inside" style="display:none;">');
								//( ID: '. $index .')
								//$form->addDropdown("field_type[{$index}]", "Type","", $select_fields, $this->formGenerator->get_option($index,"type"), array("class"=>"field_type validate[required]",'data-value'=>$index));
								
								$form->openSection("formContainer_".$index);
								
									if(isset($this->formGenerator->homepageData[$index]) && is_array($this->formGenerator->homepageData[$index])){
										
										$form->addHidden("vum_index[$index]", "","", $index);
										$form->addHidden("vum_id[$index]", "","", $index);
										$form->addHidden("field_type[$index]", "","", $this->formGenerator->get_option($index,"type"));
										
										if($this->formGenerator->get_option($index,"type") != "Linebreak"){
											$form->addInput("title[{$index}]", "Title","", $this->formGenerator->get_option($index,"title"),array("class"=>"title validate[required]"));
										}
										
										if($this->formGenerator->get_option($index,"type") != "Linebreak" && $this->formGenerator->get_option($index,"type") !="Wysiwyg"){
											$form->addInput("description[{$index}]", "Description","", $this->formGenerator->get_option($index,"description"));			
										}
										
										if($this->formGenerator->get_option($index,"type") == "YesNo"){
											$settings = json_decode($this->formGenerator->get_option($index,"label"), true);
											$form->addInput("label[{$index}][1]", "Label 1","",$settings[1]);			
											$form->addInput("label[{$index}][0]", "Label 2","",$settings[0]);	
										}
									}
								$form->closeSection();
								$form->htmlcode('
										 <p><a class="del_field" data-value="'.$index.'">Delete</a> | <a class="close_field">close</a></p>
									  </div>
									</div>
								</li>');
						}
					}
							$form->htmlcode('</ul>');
							
							$current_count_fields = 0;
							
							$form->addHidden("fornIDs", "","", implode(",", $fornIDs) );
							
							$form->htmlcode('<div id="vum_newform">');
							$form->addDropdown("field_type_options", "Add New: ","", $select_fields, '', array("class"=>"field_type_options",'data-value'=>$current_count_fields));
							$form->htmlcode("</div>");
		
					$form->closeForm("edit_view_submit");
					$form->htmlcode('<div id="code_container">');
					$form->htmlcode($viewcondestr);
					$form->htmlcode('</div></div>');
					
		}elseif($this->visible_global_settings == 1  && (isset($_GET['vum_page']) && $_GET['vum_page'] == "settingsview")){				
//Global Setting Tab
					$form->htmlcode('<div id="settingsview_container">');
					$form->openForm("frm_global_settings");
					$usersRole = vumhp_user_roles();
					
						$form->addYesNo('wpm_vumHP_setting_visible',"Restrict homepage settings visibility",'', get_option('wpm_vumHP_setting_visible',true), vumhp_current_userID() );
						$form->addDropdown('wpm_vumHP_canview_role',"Minimum user roll to see plugin",'',$usersRole, get_option('wpm_vumHP_canview_role',true) );
						$form->addMediauploadSettings("wpm_vumHP_Plugin_menu", "Plugin logo 16px","Adds a 16px logo to the menu bar", get_option("wpm_vumHP_Plugin_menu",true));
						$form->addMediauploadSettings("wpm_vumHP_Plugin_title", "Heading logo 32px","Adds a 32px logo to the title page", get_option("wpm_vumHP_Plugin_title",true));
						$form->addLinebreak();
						
						$pages = $this->formGenerator->get_pages_rows();

						$form->htmlcode('<h3>Plugin Title:</h3><div class="wpm_input wpm_text">');
						$form->addInput("wpm_vumHP_plugin_name_title", "","", get_option("wpm_vumHP_plugin_name_title"));
						$form->htmlcode('</div>');
						
						$form->htmlcode('<h3>Plugin Name:</h3><div class="wpm_input wpm_text">');
						$form->addInput("wpm_vumHP_plugin_name", "","", get_option("wpm_vumHP_plugin_name"));
						$form->htmlcode('</div>');
								
						$form->htmlcode('<h3>Pages:</h3>'.
							'<div class="wpm_input wpm_text">
								<div class="wpm_form_item">
								<p><input type="text" name="vumhp_pages[1]" class="vumhp_pages validate[required]" value="'. $pages[0]->title .'" /></p>
								<div id="subpages_container">');
						
						if(count($pages)>0) {
							foreach($pages as $page) {
								if($page->id == '1') continue;
								$form->htmlcode('<p><input type="text" name="vumhp_pages['.$page->id.']" class="vumhp_pages validate[required]" value="'. $page->title.'" /><a href="#" class="vumhp_remove_page"><img src="'.WPDEV_PLUGIN_URL.'/images/xit.gif" border="0"></a></p>');
							}
						}
						
						$form->htmlcode('</div>
								<p><a class="vumhp_add_page">add subpage</a></p></div>
							</div>'
						);
					$form->closeForm("global_setting_submit");
					$form->htmlcode('</div>');
			}
		$form->htmlcode('<div id="hideElement"></div>');
		$form->htmlcode('<div id="siteurl">'.WPDEV_PLUGIN_URL.'</div>');
			
		return  $form;
	}
	/**
	 * Display HTML
	 */
	function form_view() 
	{
		$this->form = $this->form_view_define();
		$this->form->display();
	
	}
	
	function header_js()
	{
		
	}
	
	function admin_notices() {
		
		if(isset($_GET['message']))
		  vumhp_messages($_GET['message']);
		
	}
	
	function vumh_delete_field(){
		global $wpdb;
		ob_clean();
		
		$fieldID = $wpdb->escape($_REQUEST['fieldID']);
		$wpdb->query("DELETE FROM `".$wpdb->prefix."vumhp_fields` WHERE (`id`='{$fieldID}') LIMIT 1");
		
		echo json_encode(array("status"=>1));
		exit;
	}
	
	function shortcodes($id, $elements, $imagesize = ""){
		
	}
}

require_once('functions.php');

require_once('updater.php');
$updateVUM = new PluginUpdateChecker(
	updaterLocation,
		__FILE__,
        'video-user-manuals-homepage'
);

$vum_hp = new Vum_hp();
